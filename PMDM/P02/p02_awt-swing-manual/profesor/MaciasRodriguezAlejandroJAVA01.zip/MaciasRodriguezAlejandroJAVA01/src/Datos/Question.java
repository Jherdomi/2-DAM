package Datos;

/*
Clase encargada de almacenar las preguntas
*/

public class Question
{
    private String question; //Almacena la pregunta
    private String answers[] = new String[4]; //Almacena las respuestas
    private int rightAnswerPos; //Indica la posicion de la respuesta correcta.
    
    public Question(String q, String a1, String a2, String a3, String a4, int p)
    {
        question = q;
        answers[0] = a1;
        answers[1] = a2;
        answers[2] = a3;
        answers[3] = a4;
        rightAnswerPos = p;
    }
    
    public String getRightAnswer() //Devuelve la respuesta correcta.
    {
        return answers[rightAnswerPos-1];
    }
    
    public String getAnswer(int pos) //Devuelve  una respuesta.
    {
        return answers[pos-1];
    }
    
    public int getRightAnswerPos() //Devuelve la posicion de la respuesta correcta.
    {
        return rightAnswerPos;
    }
    
    public String getQuestion() //Devuelve la pregunta.
    {
        return question;
    }
}
