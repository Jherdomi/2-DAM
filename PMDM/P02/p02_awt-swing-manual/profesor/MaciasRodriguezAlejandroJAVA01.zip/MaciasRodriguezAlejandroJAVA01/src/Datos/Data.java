package Datos;

/*
Clase encargada de almacenar los datos del usuario.
*/

public class Data
{
    private int dd, mm, aa, aciertos = 0;
    private String name;
    private Question questions[] =
        {
            new Question("¿Cual es la capital de Francia?","Madrid","Berlin","Paris","Roma",3),
            new Question("¿Que es una ballena?","Pez","Mamifero","Ave","Bacteria",2),
            new Question("¿En que año empezo la guerra civil española?","1940","1939","1914","1936",4),
            new Question("¿Quien pinto la Mona Lisa?","Miro","Dali","Da Vinci","Miguel Angel",3),
            new Question("¿Cual es el pais mas pequeño del mundo?","Vaticano","Rusia","Monaco","Japon",1),
            new Question("¿Cuantas copas del mundo tiene España?","3","1","5","0",2),
            new Question("¿Quien escribio el Quijote?","Miguel Angel","Carlos Ruiz Zafon","George Martin","Cervantes",4),
            new Question("¿De que color es el caballo blanco de Santiago?","Negro","Gris","Bayo","Blanco",4),
            new Question("¿Cuantos continentes hay en la Tierra?","5","1","3","7",1),
            new Question("¿De que color son los flamencos?","Azul","Blanco","Rosa","Verde",3)
        };
    
    public Question[] getQuestions() //Devuelve el array de preguntas.
    {
        return questions;
    }
    
    public int getAciertos() //Devuelve el numero de aciertos.
    {
        return aciertos;
    }
    
    public Question getQuestion(int pos)
    {
        return questions[pos-1];
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getDD()
    {
        return dd;
    }
    
    public int getMM()
    {
        return mm;
    }
    
    public int getAA()
    {
        return aa;
    }
    
    public void setAciertos() //Suma un acierto
    {
        aciertos+=1;
    }
    
    public void setDD(int d)
    {
        dd = d;
    }
    
    public void setMM(int m)
    {
        mm = m;
    }
    
    public void setAA(int a)
    {
        aa = a;
    }
    
    public void setName(String n)
    {
        name = n;
    }
}
