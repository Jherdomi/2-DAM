package Controladora;

/*
Clase encargada de mostrar los JPanel e iniciar las diferentes partes del programa.
*/

import Datos.Data;
import Vista.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

public class Control extends JFrame
{
    private AskUser askUser; //Declaracion de la clase encargada de recibir el nombre y la fecha de nacimiento del usuario.
    private AskQuestion askQuestion; //Declaracion de la clase encargada de mostrar las preguntas.
    private FinalWindow finalW; //Declaracion de la clase encargada de mostrar el nombre, la edad y la puntuacion del usuario.
    private Data data; //Declaracion de la clase encargada de almacenar datos.
    
    public static void main(String[] args)
    {
        Control Go = new Control(); //Crea un objeto de si mismo e inicia el programa.
        Go.startAskUser();
    }
    
    private void startAskUser() //Inicia y muestra el objeto askUser.
    {
        askUser = new AskUser();
        data = new Data();
        
        askUser.setControl(this); //Envia al objeto un objeto de la clase Control para que, cuando termine de recibir informacion, pueda pasar a la siguiente clase.
        askUser.setData(data); //Envia el objeto data que almacene la informacion recogida.
        
        showWindow(askUser.getPanel()); //Envia el JPanel del objeto askUser para que se muestre.
    }
    
    public void startAskQuestions() //Inicia y muestra el objeto askQuestion.
    {
        askQuestion = new AskQuestion(askUser.getData(), this); //Crea el objeto con los datos recogidos por el objeto askUser.
        showWindow(askQuestion.getJPanel());  //Envia el JPanel del objeto askQuestion para que se muestre.
    }
    
    public void startFinalWindow() //Inicia y muestra el objeto finalW.
    {
        finalW = new FinalWindow(askQuestion.getData()); //Crea el objeto con los datos recogidos por el objeto askQuestion.
        showWindow(finalW.getJPanel()); //Envia el JPanel del objeto finalW para que se muestre.
    }
    
    private void showWindow(JPanel panel) //Se encarga de mostrar los JPanel.
    {
        addWindowListener(new WindowAdapter()
                            {
                                public void windowClosing(WindowEvent e)
                                {
                                    System.exit(0);
                                }
                            });
        
        pack();
        setTitle("Examen tipo test.");
        setContentPane(panel);
        setVisible(true);
        setSize(480, 350);
        setLocation(400,300);
    }
}