package Vista;

/*
Clase encargada de recoger el nombre y la fecha de nacimiento del usuario.
*/

import Datos.Data;
import Controladora.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

import java.text.*;

public class AskUser extends JFrame implements ActionListener
{
    //Declaracion de clases
    private Data data;
    private Control control;
    
    //Etiquetas para identificar los campos de texto
    private JLabel nameLabel;
    private JLabel dateLabel;
    private JLabel dayLabel, monthLabel, yearLabel;

    //Botones
    private JButton continueButton;
    
    //Text fields para introducir datos
    private TextField nameField;
    
    //Almacena la fecha de nacimiendo indicada por el usuario
    private String day, month, year;
    
    //Indica si los datos del usuario son correctos
    private boolean correcto;
    
    //Listas desplegables para la fecha de nacimiento.
    private JComboBox chooseDay, chooseMonth, chooseYear; 
    
    //JPanel principal donde se almacenan los demas elementos.
    private JPanel mainPanel;
    
    public AskUser()
    {
        //Crea las etiquetas.
        nameLabel = new JLabel("Introduzca su nombre:");
        dateLabel = new JLabel("Introduzca su fecha de nacimiento:");
        dayLabel = new JLabel("Dia:");
        monthLabel = new JLabel("Mes:");
        yearLabel = new JLabel("Año:");
        
        //Crea el boton de continuar y le añade un listener
        continueButton = new JButton("Continuar");
        continueButton.addActionListener(this);

        //Campo para el nombre
        nameField = new TextField(50);
        
        initializeJComboBox(); //Inicializa las listas desplegables.

        //Panel que almacena los elementos
        JPanel elementPanel = new JPanel();
        elementPanel.setLayout(new GridLayout(5, 0)); //5 filas y 1 columna
        elementPanel.add(nameLabel);
        elementPanel.add(nameField);
        elementPanel.add(dateLabel);
        
        //Panel para la fecha de nacimiento
        JPanel fechaPanel = new JPanel();
        fechaPanel.setLayout(new GridLayout(2, 3)); //Dos filas y tres columnas
        fechaPanel.add(dayLabel);
        fechaPanel.add(monthLabel);
        fechaPanel.add(yearLabel);
        chooseDay.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20) );
        fechaPanel.add(chooseDay);
        chooseMonth.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20) );
        fechaPanel.add(chooseMonth);
        chooseYear.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20) );
        fechaPanel.add(chooseYear);
        
        elementPanel.add(fechaPanel);
        
        //Panel para continuar
        JPanel continuarPanel = new JPanel();
        continuarPanel.setLayout(new BoxLayout(continuarPanel, BoxLayout.Y_AXIS));
        continueButton.setAlignmentX(CENTER_ALIGNMENT);
        continuarPanel.setBorder( BorderFactory.createEmptyBorder(20, 0, 0, 0) );
        continuarPanel.add(continueButton);
        
        elementPanel.add(continuarPanel);

        //Panel principal
        mainPanel = new JPanel();
        mainPanel.setBorder( BorderFactory.createEmptyBorder(20, 20, 20, 20) );
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(elementPanel, BorderLayout.CENTER);
    }
    
    public void actionPerformed(ActionEvent e) //Acciones a realizar cuando se pulsar en el boton continueButton.
    {
        correcto = true;
        data.setName(nameField.getText()); //Asigna el contenido del campo del nombre a la variable del objeto data.

        if(data.getName().length() == 0) //Comprueba que se haya escrito algo en el nombre.
        {
            System.err.println("No se ha introducido el nombre.");
            correcto = false;
        }
        else
            if(!checkName()) //Comprueba que el nombre no tenga carácteres no válidos, como números o símbolos.
            {
                correcto = false;
                System.err.println("Nombre no válido.");
            }

        try
        {
            //Convierte los String de la fecha a numeros y los almacena en el objeto data.
            data.setDD(Integer.parseInt(day));
            data.setMM(Integer.parseInt(month));
            data.setAA(Integer.parseInt(year));
            
            if(!checkDate()) //Comprueba que la fecha sea correcta.
            {
                correcto = false;
                System.err.println("La fecha es incorrecta.");
            }
        }
        catch(NumberFormatException error) //Si no se puede realizar la conversion a numero, significa que el usuario no ha escogido una fecha correcta.
        {
            System.err.println("Datos de la fecha de nacimiento insuficientes.");
            correcto = false;
        }
        
        if(correcto) //Si los datos son correctos, se inicia el metodo que crea el objeto de la siguiente fase.
            control.startAskQuestions();
    }
    
    private void initializeJComboBox() //Inicializa las listas desplegables
    {
        chooseDay = new JComboBox();
        
        //Asigna valores a la lista desplegable
        chooseDay.setModel(new DefaultComboBoxModel(new String[] {"","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"}));
        
        //Da acciones a la lista.
        chooseDay.addItemListener(new ItemListener()
                                    {
                                        public void itemStateChanged(ItemEvent e)
                                        {
                                            day = chooseDay.getSelectedItem().toString(); //En caso de elegir un dato, la variable almacena el valor.
                                        }
                                    }); 
        
        chooseMonth = new JComboBox();
        chooseMonth.setModel(new DefaultComboBoxModel(new String[] {"","1","2","3","4","5","6","7","8","9","10","11","12"}));
        
        chooseMonth.addItemListener(new ItemListener()
                                    {
                                        public void itemStateChanged(ItemEvent e)
                                        {
                                            month = chooseMonth.getSelectedItem().toString();
                                        }
                                    });
        
        chooseYear = new JComboBox();
        chooseYear.setModel(new DefaultComboBoxModel(new String[] {"","1980","1981","1982","1983","1984","1985","1986","1987","1988","1989","1990","1991","1992","1993","1994","1995","1996","1997","1998","1999","2000"}));
        
        chooseYear.addItemListener(new ItemListener()
                                    {
                                        public void itemStateChanged(ItemEvent e)
                                        {
                                            year = chooseYear.getSelectedItem().toString();
                                        }
                                    });
    }

    private boolean checkDate()
    {
	switch(data.getMM())
	{
            case 4:
            case 6:
            case 9:
            case 11:
            {
                if (data.getDD() > 30)
                    return false;
                break;
            }
            case 2:
            {
                if (data.getDD() > 30 || ( (data.getAA()%400 != 0 && data.getAA()%100 == 0 || !(data.getAA()%400 == 0 || data.getAA()%4 == 0))  && data.getDD() > 28))
                    return false;
            }
	}
        
        return true;
    }
    
    private boolean checkName()
    {
        for(int n=0;n<data.getName().length();n++)
            if(!Character.isLetter(data.getName().charAt(n)) && data.getName().charAt(n) != ' ')
                return false;
        return true;
    }
    
    public void setControl(Control c)
    {
        control = c;
    }
    
    public JPanel getPanel()
    {
        return mainPanel;
    }
    
    public void setData(Data d)
    {
        data = d;
    }
    
    public Data getData()
    {
        return data;
    }
}
