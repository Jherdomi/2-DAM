package Vista;

/*
Clase encargada de mostrar las preguntas al usuario y almacenar el numero de aciertosLabel.
*/

import Datos.Data;
import Controladora.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

public class AskQuestion extends JFrame implements ActionListener
{
    //Objetos de clases
    private Data data;
    private Control control;
    
    //JPanel principal
    private JPanel mainPanel;
    
    //Pregunta en la que se esta actualmente
    private int posQ=1;
    
    //Botones para las respuestas
    private JButton ans1Button, ans2Button, ans3Button, ans4Button;
    
    //Boton para continuar
    private JButton nextButton;
    
    //Auxiliar para almacenar el botón pulsado.
    private JButton aux;
    
    //Etiquetas
    private JLabel questionLabel, numberQuestionLabel, aciertosLabel, resultLabel;
    
    //Indican respestivalente si el usuario ha contestado a la pregunta, y por tanto, debe pulsar en continuar, y si se ha acertado en la respuesta.
    private boolean contestar, acierto;
    
    public AskQuestion(Data d, Control c)
    {
        //Guarda los objetos.
        control = c;
        data = d;
        
        //Crea los botones
        ans1Button = new JButton();
        ans2Button = new JButton();
        ans3Button = new JButton();
        ans4Button = new JButton();
        nextButton = new JButton("Continuar");
        
        //Crea las etiquetas
        questionLabel = new JLabel();
        numberQuestionLabel = new JLabel();
        aciertosLabel = new JLabel();
        resultLabel = new JLabel();
        
        //Pone listener a todos los objetos.
        ans1Button.addActionListener(this);
        ans2Button.addActionListener(this);
        ans3Button.addActionListener(this);
        ans4Button.addActionListener(this);
        nextButton.addActionListener(this);
        
        //JPanel para los elementos
        JPanel elementPanel = new JPanel();
        elementPanel.setLayout(new GridLayout(7, 0)); //7 filas y 1 columna
        
        //JPanel para el enunciado
        JPanel enunciado = new JPanel();
        enunciado.setLayout(new GridLayout(0, 3)); //1 fila y 3 columnas
        enunciado.add(numberQuestionLabel);
        enunciado.add(aciertosLabel);
        enunciado.add(resultLabel);
        
        elementPanel.add(enunciado);
        elementPanel.add(questionLabel);
        elementPanel.add(ans1Button);
        elementPanel.add(ans2Button);
        elementPanel.add(ans3Button);
        elementPanel.add(ans4Button);
        
        //JPanel para el boton nextButton
        JPanel panelNext = new JPanel();
        panelNext.add(nextButton);
        panelNext.setBorder( BorderFactory.createEmptyBorder(8, 0, 0, 0) );
        
        elementPanel.add(panelNext);

        //Panel principal
        mainPanel = new JPanel();
        mainPanel.setBorder( BorderFactory.createEmptyBorder(20, 20, 20, 20) );
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(elementPanel, BorderLayout.CENTER);
        
        nextButtonQuestion(); //Lleva a la primer pregunta.
    }
    
    private void nextButtonQuestion() //Cambia los label los datos se la siguiente pregunta.
    {
        contestar = true;
        acierto = false;
        
        //Actualiza el texto de los label con los datos del objeto data y les pone su color por defecto.
        ans1Button.setText(data.getQuestion(posQ).getAnswer(1));
        ans1Button.setBackground(null);
        ans2Button.setText(data.getQuestion(posQ).getAnswer(2));
        ans2Button.setBackground(null);
        ans3Button.setText(data.getQuestion(posQ).getAnswer(3));
        ans3Button.setBackground(null);
        ans4Button.setText(data.getQuestion(posQ).getAnswer(4));
        ans4Button.setBackground(null);
        questionLabel.setText(data.getQuestion(posQ).getQuestion());
        
        numberQuestionLabel.setText(posQ+"/"+data.getQuestions().length); //Indica el numero de la pregunta
        resultLabel.setText(""); //Borra el texto que muestra si una respuesta es correcta o incorrecta.
        aciertosLabel.setText("Aciertos: "+data.getAciertos()*100/data.getQuestions().length+"%"); //Indica el porcentaje de aciertosLabel.
    }
    
    public void actionPerformed(ActionEvent e) //Acciones
    {
        if(e.getSource() != nextButton) //Si se ha pulsado en un respuesta 
        {
            if(contestar) //Si aun no se ha respondido la pregunta
            {
                aux = (JButton) e.getSource(); //Almacena el botón pulsado.
                contestar = false; //Se indica que ya se ha contestado a la pregunta.
                
                //Comprueba que se haya pulsado en la respuesta correcta.
                for(int n=1;n<=4 && !acierto;n++)
                    if(aux.getText().equals(data.getQuestion(posQ).getRightAnswer()))
                        acierto = true;
                
                updateInfo(); //Actualiza la informacion en base a la respuesta.
                
                if(acierto) //Si acierta, pinta el botón pulsado de color verde.
                    aux.setBackground(Color.GREEN);
                else
                {
                    switch(data.getQuestion(posQ).getRightAnswerPos()) //Si falla, pinta la respuesta de color verde.
                    {
                        case 1:
                            ans1Button.setBackground(Color.GREEN);
                            break;
                        case 2:
                            ans2Button.setBackground(Color.GREEN);
                            break;
                        case 3:
                            ans3Button.setBackground(Color.GREEN);
                            break;
                        case 4:
                            ans4Button.setBackground(Color.GREEN);
                    }
                    
                    aux.setBackground(Color.RED); //Si falla, pinta el botón pulsado de color rojo.
                }
                
                posQ++; //Suma uno al numero de la pregunta.
            }
            else
                System.err.println("Ya ha respondido a la pregunta. Pulse en Continuar.");
        }
        else
            if(!contestar) //Si se pulsa en el boton continuar habiendo respondido a la pregunta.
            {
                if(posQ <= data.getQuestions().length) //Si aun no se ha llegado a la ultima pregunta, pasa a la siguiente.
                    nextButtonQuestion();
                else
                    control.startFinalWindow(); //Si se ha llegado a la ultima pregunta, se pasa a la siguiente parte del programa.
            }
            else
                System.err.println("Antes de continuar debe responder a la pregunta.");
    }
    
    private void updateInfo() //Actualiza informacion cuando se responde una pregunta
    {
        if(acierto) //Actualiza el label que muestra si una pregunta es correcta o incorrecta y actualiza el numero de aciertosLabel en el objeto data.
        {
            data.setAciertos();
            resultLabel.setText("Correcto.");
        }
        else
            resultLabel.setText("Incorrecto.");
        
        aciertosLabel.setText("Aciertos: "+data.getAciertos()*100/data.getQuestions().length+"%"); //Actualiza los aciertosLabel.
    }
    
    public JPanel getJPanel()
    {
        return mainPanel;
    }
    
    public Data getData()
    {
        return data;
    }
}