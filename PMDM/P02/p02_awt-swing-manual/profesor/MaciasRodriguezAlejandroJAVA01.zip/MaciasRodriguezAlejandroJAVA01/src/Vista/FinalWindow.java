package Vista;

/*
Clase encargada de mostrar el nombre, la edad y el numero de aciertosLabel del usuario.
*/

import Datos.Data;

import java.awt.*;
import java.awt.event.*;

import java.util.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

public class FinalWindow extends JFrame
{
    //JPanel principal
    private JPanel mainPanel;
    
    //Declaracion de objetos
    private Data data;
    
    //Calendario que obtiene la fecha actual.
    Calendar calendar = Calendar.getInstance();
    
    //Etiquetas
    private JLabel nameLabel, aciertosLabel, ageLabel;
    
    public FinalWindow(Data d)
    {
        data = d;
        
        //Crea las etiquetas
        nameLabel = new JLabel("Nombre: "+ data.getName());
        aciertosLabel = new JLabel("Aciertos: "+ data.getAciertos()+"/"+data.getQuestions().length+"  -  "+data.getAciertos()*100/data.getQuestions().length+"%");
        ageLabel = new JLabel("Edad: "+getAge());
        
        //JPanel que almacena los elementos
        JPanel elementPanel = new JPanel();
        elementPanel.setLayout(new BoxLayout(elementPanel, BoxLayout.Y_AXIS));
        nameLabel.setAlignmentX(LEFT_ALIGNMENT);
        elementPanel.add(nameLabel);
        ageLabel.setAlignmentX(LEFT_ALIGNMENT);
        elementPanel.add(ageLabel);
        aciertosLabel.setAlignmentX(LEFT_ALIGNMENT);
        elementPanel.add(aciertosLabel);
        
        //JPanel principal
        mainPanel = new JPanel();
        mainPanel.setBorder( BorderFactory.createEmptyBorder(20, 20, 20, 20) );
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(elementPanel, BorderLayout.CENTER);
    }
    
    public JPanel getJPanel()
    {
        return mainPanel;
    }
    
    private int getAge() //Halla la edad del usuario.
    {
        if( data.getMM() < calendar.get(Calendar.MONTH) || 
            (data.getMM() == calendar.get(Calendar.MONTH) && data.getDD() <= calendar.get(Calendar.DATE))
          )
            return calendar.get(Calendar.YEAR) - data.getAA();
        else
            return calendar.get(Calendar.YEAR) - data.getAA()-1;
    }
}