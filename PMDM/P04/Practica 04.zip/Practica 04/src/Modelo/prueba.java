/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Controlador.*;
import java.util.ArrayList;



/**
 *
 * @author alumno
 */
public class prueba {
    
    public static void main(String[] args) {
//        Cuenta c1 = new Cuenta("Pepe");
//        Cuenta c2 = new Cuenta();
//        Cuenta c3 = new Cuenta();
//        Cuenta c4 = new Cuenta();
//        Cuenta c5 = new Cuenta();
//        Cuenta c6 = new Cuenta();
        
//        System.out.println(c1.toString());
//        System.out.println(c2.toString());
//        System.out.println(c3.toString());
//        System.out.println(c4.toString());
//        System.out.println(c5.toString());
//        System.out.println(c6.toString());
        

    
        
//        System.out.println(c1);
          ArrayList<String> cad = new ArrayList<>();

//          cad = Fichero.leerFichero();
    
        Lista l = new Lista(10);

        l.insertarNodo(1, new CuentaAhorro("tit", 12.0f, 11.0f, "12/12/2020",12.0f, "qwe"));
        l.rellenarLista(l);


    }

    
    
    
    
}
